# Load necessary libraries
library(readxl)
library(dplyr)
library(ggplot2)
library(factoextra)
library(NbClust)
library(cluster)
library(caret)
library(stats)
library(data.table)
library(fpc)

install.packages("fpc","caret")


# Load the dataset
wine_data <- read_excel("C:/Users/USER/Desktop/jevin ML/Whitewine_v6.xlsx")
print(wine_data)
# Selecting the first 11 chemical attributes
wine_data <- select(wine_data, 1:11)

# Data Preprocessing
## Scaling the data
wine_scaled <- scale(wine_data)

## Outlier Detection and Removal
iqr_values <- apply(wine_scaled, 2, IQR)

# Define function to remove outliers using IQR method
remove_outliers <- function(data, iqr_values) {
  lower_bound <- apply(data, 2, function(x) quantile(x, 0.25) - 1.5 * iqr_values)
  upper_bound <- apply(data, 2, function(x) quantile(x, 0.75) + 1.5 * iqr_values)
  
  # Remove outliers
  for (i in 1:ncol(data)) {
    data <- subset(data, data[, i] >= lower_bound[i] & data[, i] <= upper_bound[i])
  }
  
  return(data)
}

# Remove outliers using IQR method
wine_clean <- remove_outliers(wine_scaled, iqr_values)
boxplot(wine_clean)

# Now, remove outliers until none remain
while (TRUE) {
  # Calculate new IQR values
  iqr_values <- apply(wine_clean, 2, IQR)
  
  # Remove outliers based on updated IQR values
  wine_clean_new <- remove_outliers(wine_clean, iqr_values)
  
  # Check if any outliers were removed
  if (nrow(wine_clean_new) == nrow(wine_clean)) {
    break  # No more outliers were removed, exit the loop
  } else {
    wine_clean <- wine_clean_new
  }
}

# Create boxplot of cleaned data after removing all outliers
boxplot(wine_clean)


# Determining the number of clusters
## Method 1: Elbow Method
set.seed(123)
fviz_nbclust(wine_clean, kmeans, method = "wss")

## Method 2: Silhouette Method
fviz_nbclust(wine_clean, kmeans, method = "silhouette")

# Compute the gap statistic using clusGap
gap_stats <- clusGap(wine_clean, FUN = kmeans, K.max = 10, B = 100)

# Visualize the gap statistic to determine the optimal number of clusters
fviz_gap_stat(gap_stats)

## Method 4: NbClust
nb <- NbClust(wine_clean, distance = "euclidean", min.nc = 2, max.nc = 10, method = "kmeans")
barplot(table(nb$Best.nc), xlab = "Number of Clusters", ylab = "Votes", main = "NbClust Results")

# K-means Clustering using Optimal Number of Clusters
optimal_clusters <- 2  
set.seed(123)
kmeans_result <- kmeans(wine_clean, centers = optimal_clusters, nstart = 25)

# Results from K-means
print(kmeans_result$centers)
cat("Within cluster sum of squares:", kmeans_result$tot.withinss, "\n")
cat("Total sum of squares:", sum((wine_clean - apply(wine_clean, 2, mean))^2), "\n")
cat("Between cluster sum of squares:", kmeans_result$betweenss, "\n")

# Silhouette Analysis
silhouette_scores <- silhouette(kmeans_result$cluster, dist(wine_clean))
fviz_silhouette(silhouette_scores)

# PCA Analysis
pca_result <- prcomp(wine_scaled, scale. = TRUE)
fviz_eig(pca_result, addlabels = TRUE, ylim = c(0, 100))

# Selecting PCs with cumulative variance > 85%
pca_data <- data.frame(pca_result$x)
cum_var <- cumsum(pca_result$sdev^2 / sum(pca_result$sdev^2)) * 100
pca_selected <- pca_data[, cum_var > 85]

# Clustering on PCA-reduced dataset
set.seed(123)
pca_kmeans_result <- kmeans(pca_selected, centers = optimal_clusters, nstart = 25)
print(pca_kmeans_result$centers)
fviz_cluster(pca_kmeans_result, data = pca_selected)

# Silhouette plot for PCA-based clustering
pca_silhouette_scores <- silhouette(pca_kmeans_result$cluster, dist(pca_selected))
fviz_silhouette(pca_silhouette_scores)


# Calculate Calinski-Harabasz index to evaluate clustering quality
calin_index <- calinhara(pca_selected, pca_kmeans_result$cluster, optimal_clusters)

# Print the Calinski-Harabasz index
cat("Calinski-Harabasz index:", calin_index, "\n")
